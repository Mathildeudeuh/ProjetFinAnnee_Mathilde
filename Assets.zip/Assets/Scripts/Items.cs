﻿using UnityEngine;


[RequireComponent(typeof(ItemsAddTime))]
[RequireComponent(typeof(Timer))]

public abstract class Items : MonoBehaviour
{
    [SerializeField] public GameObject star;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        star.SetActive(false);
        AddTime();

    }

    public abstract void AddTime();
}
